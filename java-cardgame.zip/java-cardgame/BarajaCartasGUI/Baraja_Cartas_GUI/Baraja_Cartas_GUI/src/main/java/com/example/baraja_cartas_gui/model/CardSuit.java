package com.example.baraja_cartas_gui.model;

public enum CardSuit {
    GOLD,
    SWORDS,
    CUPS,
    CLUBS
}
