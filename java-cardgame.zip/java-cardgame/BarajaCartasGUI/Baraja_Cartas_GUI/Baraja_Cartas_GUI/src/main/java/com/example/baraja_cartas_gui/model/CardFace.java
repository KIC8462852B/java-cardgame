package com.example.baraja_cartas_gui.model;

//JACK=SOTA, KNIGHT=CABALLO,

public enum CardFace {
    JACK,
    KNIGHT,
}
